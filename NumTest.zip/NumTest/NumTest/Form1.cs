﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace NumTest
{
    public partial class Form1 : Form
    {
        int num1, num2, num3, num4;
        int count = 0;
        bool show = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            num3 = rand.Next(1000, 9999);
            num4 = rand.Next(1000, 9999);
            
            num1 = rand.Next(1000, 9999);
            string num1S = num1.ToString();
            num1S = num1S.Substring(0, 1) + (num1S.Substring(1, 1) == "9" ? "8" : num1S.Substring(1, 1)) + num1S.Substring(2, 1) + num1S.Substring(3, 1);
            num1 = Convert.ToInt32(num1S);
            string num2S = rand.Next(1, Convert.ToInt32(num1S.Substring(0,1))).ToString() +
                (num1S.Substring(1, 1) == "8" ? "9" : rand.Next(Convert.ToInt32(num1S.Substring(1, 1)), 9).ToString()) +
                rand.Next(Convert.ToInt32(num1S.Substring(2, 1)), 9).ToString() + rand.Next(Convert.ToInt32(num1S.Substring(3, 1)), 9).ToString();
            num2 = Convert.ToInt32(num2S);

         
            if (num2 > num1)
            {
                num1S = num1.ToString();
                num1S = (Convert.ToInt32(num1S.Substring(0, 1)) + 1).ToString() + num1S.Substring(1, 1) + num1S.Substring(2, 1);
                num1 = Convert.ToInt32(num1S);
            }
            label1.Text = num1.ToString();
            label2.Text = num2.ToString();
            label6.Text = num3.ToString();
            label7.Text = num4.ToString();
            label3.Text = "";
            label5.Text = "";

            if (!show)
            {
                button2.Text = "Hide";
                show = true;
                label1.Text = num1.ToString();
                label2.Text = num2.ToString();
                label6.Text = num3.ToString();
                label7.Text = num4.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (show)
            {
                button2.Text = "Show";
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label6.Text = "";
                label7.Text = "";
                label5.Text = "";
            }
            else
            {
                button2.Text = "Hide";
                label1.Text = num1.ToString();
                label2.Text = num2.ToString();
                label6.Text = num3.ToString();
                label7.Text = num4.ToString();
            }
            show = !show;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!show)
            {
                button2.Text = "Hide";
                show = true;
                label6.Text = num1.ToString();
                label7.Text = num2.ToString();
            }
            label5.Text = (num3 + num4).ToString();
            count++;
            label4.Text = count.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!show)
            {
                button2.Text = "Hide";
                show = true;
                label1.Text = num1.ToString();
                label2.Text = num2.ToString();
            }
            label3.Text = (num1 - num2).ToString();
            count++;
            label4.Text = count.ToString();
        }
    }
}
